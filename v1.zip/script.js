document.addEventListener('DOMContentLoaded', () => {
    const sortearBtn = document.getElementById('sortearBtn');
    const copiarBtn = document.getElementById('copiarBtn');
    const resultadoDiv = document.getElementById('resultado');
    const errorMessageDiv = document.getElementById('error-message');
    const historicoDiv = document.getElementById('historico');
    const limparHistoricoBtn = document.getElementById('limparHistoricoBtn');
    const noHistoryMessage = document.getElementById('no-history-message');

    const TOTAL_NUMEROS = 50;
    const LIMITE_NUMERO = 99; // Números de 0 a 99
    const LOCAL_STORAGE_KEY = 'sorteiosHistorico';

    let numerosSorteadosAtuais = []; // Armazena o resultado do sorteio atual

    // --- Funções de Utilitário ---

    // Exibe uma mensagem de erro temporária
    function showError(message) {
        errorMessageDiv.textContent = message;
        errorMessageDiv.style.display = 'block';
        setTimeout(() => {
            errorMessageDiv.style.display = 'none';
        }, 5000); // Esconde a mensagem após 5 segundos
    }

    // Esconde a mensagem de erro
    function hideError() {
        errorMessageDiv.style.display = 'none';
    }

    // Adiciona um zero à esquerda para números menores que 10 (formatação)
    function padZero(num) {
        return num < 10 ? '0' + num : num;
    }

    // Formata a data e hora atual
    function getFormattedDateTime() {
        const now = new Date();
        const day = padZero(now.getDate());
        const month = padZero(now.getMonth() + 1);
        const year = now.getFullYear();
        const hours = padZero(now.getHours());
        const minutes = padZero(now.getMinutes());
        const seconds = padZero(now.getSeconds());
        return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
    }

    // --- Funções de Histórico ---

    // Carrega o histórico do Local Storage
    function carregarHistorico() {
        const historicoRaw = localStorage.getItem(LOCAL_STORAGE_KEY);
        return historicoRaw ? JSON.parse(historicoRaw) : [];
    }

    // Salva o histórico no Local Storage
    function salvarHistorico(historico) {
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(historico));
    }

    // Renderiza o histórico na interface
    function renderizarHistorico() {
        const historico = carregarHistorico();
        historicoDiv.innerHTML = ''; // Limpa o conteúdo atual

        if (historico.length === 0) {
            noHistoryMessage.style.display = 'block';
            limparHistoricoBtn.style.display = 'none';
            historicoDiv.appendChild(noHistoryMessage); // Garante que a mensagem esteja no lugar certo
            return;
        } else {
            noHistoryMessage.style.display = 'none';
            limparHistoricoBtn.style.display = 'inline-flex';
        }

        historico.forEach(item => {
            const historicoItemDiv = document.createElement('div');
            historicoItemDiv.classList.add('historico-item');

            const dataHoraSpan = document.createElement('span');
            dataHoraSpan.classList.add('data-hora');
            dataHoraSpan.textContent = item.timestamp;
            historicoItemDiv.appendChild(dataHoraSpan);

            const numerosHistoricoSpan = document.createElement('span');
            numerosHistoricoSpan.classList.add('numeros-historico');
            numerosHistoricoSpan.innerHTML = item.numbers.map(num => `<span class="num">${num}</span>`).join('');
            historicoItemDiv.appendChild(numerosHistoricoSpan);

            historicoDiv.prepend(historicoItemDiv); // Adiciona os mais recentes no topo
        });
    }

    // Limpa o histórico e atualiza a interface
    function limparHistorico() {
        if (confirm('Tem certeza que deseja limpar todo o histórico de sorteios?')) {
            localStorage.removeItem(LOCAL_STORAGE_KEY);
            renderizarHistorico(); // Re-renderiza para mostrar que está vazio
        }
    }

    // --- Funções de Sorteio ---

    // Sorteia os números com efeito de animação
    async function sortearNumeros() {
        hideError();
        sortearBtn.disabled = true;
        copiarBtn.style.display = 'none';
        resultadoDiv.innerHTML = '';
        numerosSorteadosAtuais = [];

        const numerosDisponiveis = Array.from({ length: LIMITE_NUMERO + 1 }, (_, i) => i);

        if (TOTAL_NUMEROS > numerosDisponiveis.length) {
            showError(`Erro: Não é possível sortear ${TOTAL_NUMEROS} números únicos de ${LIMITE_NUMERO + 1} opções disponíveis.`);
            sortearBtn.disabled = false;
            return;
        }

        // Embaralha o array de números disponíveis (Algoritmo Fisher-Yates otimizado)
        for (let i = numerosDisponiveis.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [numerosDisponiveis[i], numerosDisponiveis[j]] = [numerosDisponiveis[j], numerosDisponiveis[i]];
        }

        // Cria os elementos dos números temporariamente para a animação
        const elementosTemporarios = [];
        for (let i = 0; i < TOTAL_NUMEROS; i++) {
            const numeroElemento = document.createElement('span');
            numeroElemento.classList.add('numero', 'sorteando');
            // Define um número aleatório inicial para o efeito de giro
            numeroElemento.textContent = Math.floor(Math.random() * (LIMITE_NUMERO + 1));
            resultadoDiv.appendChild(numeroElemento);
            elementosTemporarios.push(numeroElemento);
        }

        // Espera um pouco para a animação iniciar em todos os números
        await new Promise(resolve => setTimeout(resolve, 100));

        // Animação e fixação dos números
        for (let i = 0; i < TOTAL_NUMEROS; i++) {
            const numeroFinal = numerosDisponiveis[i];
            const elemento = elementosTemporarios[i];

            // Remove a animação e define o número final
            elemento.classList.remove('sorteando');
            elemento.textContent = numeroFinal;
            numerosSorteadosAtuais.push(numeroFinal);

            // Pequeno atraso para a animação sequencial
            await new Promise(resolve => setTimeout(resolve, 70));
        }

        // Garante que o array esteja ordenado no final
        numerosSorteadosAtuais.sort((a, b) => a - b);

        // Atualiza a exibição final com os números ordenados
        resultadoDiv.innerHTML = numerosSorteadosAtuais.map(num => `<span class="numero">${num}</span>`).join('');

        // Salva o sorteio no histórico
        const historico = carregarHistorico();
        historico.push({
            timestamp: getFormattedDateTime(),
            numbers: numerosSorteadosAtuais
        });
        salvarHistorico(historico);
        renderizarHistorico(); // Re-renderiza o histórico com o novo item

        copiarBtn.style.display = 'inline-flex';
        sortearBtn.disabled = false;
    }

    // Função para copiar resultado para a área de transferência
    function copiarResultado() {
        const textoResultado = numerosSorteadosAtuais.join(', ');
        navigator.clipboard.writeText(textoResultado)
            .then(() => {
                // Feedback visual
                const originalText = copiarBtn.innerHTML;
                copiarBtn.innerHTML = '<i class="fas fa-check"></i> Copiado!';
                copiarBtn.classList.remove('success-btn');
                copiarBtn.classList.add('primary-btn');
                setTimeout(() => {
                    copiarBtn.innerHTML = originalText;
                    copiarBtn.classList.remove('primary-btn');
                    copiarBtn.classList.add('success-btn');
                }, 1500);
            })
            .catch(err => {
                console.error('Erro ao copiar texto: ', err);
                showError('Falha ao copiar o resultado. Por favor, tente novamente.');
            });
    }

    // --- Event Listeners e Inicialização ---

    sortearBtn.addEventListener('click', sortearNumeros);
    copiarBtn.addEventListener('click', copiarResultado);
    limparHistoricoBtn.addEventListener('click', limparHistorico);

    // Carrega o histórico ao carregar a página
    renderizarHistorico();
});